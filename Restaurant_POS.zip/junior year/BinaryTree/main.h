#pragma once
#include "Node.h"
#include "BST.h"

class main
{
public:
	main();
	~main();
};

