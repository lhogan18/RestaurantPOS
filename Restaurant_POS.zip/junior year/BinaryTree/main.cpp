#include "main.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>

using namespace std;

int main() {
	vector<int> Data1;
	
	int n;
	//ifstream file1("C:\\junior year\\Data1.txt"); //opening the first file
	ifstream file1("C:\\junior year\\Data2.txt"); //opening the first file


	if (file1) {
		while(file1 >> n)
			Data1.push_back(n);
	}

	file1.close();

	for (int i = 0; i < Data1.size(); i++) {
		cout << Data1.at(i) << " ";
	}
	cout << endl;

	BST* bst = new BST();
	for (int data : Data1) {
		bst->insert(data);
	}
	
	if (bst->isBalanced() == true)
		cout << "tree is balanced" << endl;
	else
		cout << "tree is not balanced" << endl;

	cout << "The height of the tree is " << bst->getHeight() << endl;
	
	cout << "The max node is " << bst->maxNode() << endl;
	cout << "The min node is " << bst->minNode() << endl;
	
	vector<int> preList = bst->preOrder();
	vector<int> inList = bst->inOrder();
	vector<int> postList = bst->postOrder();

	cout << "Preorder traversal of the binary tree: ";
	for (int i = 0; i < preList.size(); i++)
		cout << preList.at(i) << " ";
	cout << "\nInorder traversal of the binary tree: ";
	for (int i = 0; i < inList.size(); i++)
		cout << inList.at(i) << " ";
	cout << "\nPostorder traversal of the binary tree: ";
	for (int i = 0; i < postList.size(); i++)
		cout << postList.at(i) << " ";
	cout << endl;
	system("pause");
	return 0;
}
