#pragma once
#include "Node.h"
#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

class BST
{
	public:
		BST();
		~BST();

		void insert(int data);
		bool isBalanced();
		int getHeight();
		void deleteBST();
		std::vector<int> inOrder();
		std::vector<int> preOrder();
		std::vector<int> postOrder();
		int maxNode();
		int minNode();
		
	private:
		std::vector<int> preList;
		std::vector<int> inList;
		std::vector<int> postList;
		Node* node;
		void insert(Node * treeNode, int data);
		bool isBalanced(Node *treeNode);
		int getHeight(Node *treeNode);
		void deleteBST(Node *treeNode);
		void inOrder(Node * treeNode);
		void preOrder(Node * treeNode);
		void postOrder(Node * treeNode);
		int maxNode(Node * treeNode);
		int minNode(Node * treeNode);
};

