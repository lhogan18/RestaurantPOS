#include "main.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <array>
#include <algorithm>
#include <list>

using namespace std;

struct Node {
	public: 
		int data;
	Node * next;
};

class llist {
	private:
		Node *head, *tail;
	public:
		llist() {
			head = NULL;
			tail = NULL;
		}
		void Insert(int n) {
			Node *ptr = new Node;
			ptr->data = n;
			ptr->next = NULL;
			if (head == NULL) {
				head = ptr;
				tail = ptr;
			}
			else {
				tail->next = ptr;
				tail = tail->next;
			}
		}
		void PrintList() {
		    Node *ptr = new Node;
			ptr = head;
			while (ptr != NULL) {
				cout << ptr->data << " ";
				ptr = ptr->next;
			}
			cout << endl;
		}

		struct Node* FindLinear(int n) {
			Node* curr = head;
			while (curr != NULL) {
				if (curr->data == n) {
					return curr;
				}
				curr = curr->next;
			}
			return NULL;
		}
		struct Node* FindMiddle(Node* beg, Node* end) {
			if (beg == NULL)
				return NULL;
			struct Node* a = beg;
			struct Node* b = beg->next;

			while (b != end) {
				b = b->next;
				if (b != end) {
					a = a->next;
					b = b->next;
				}
			}
			return a;
		}
		struct Node* FindBinary(int n) {
			Node* beg = head;
			Node* end = NULL;
			do {
				Node* mid = FindMiddle(beg, end);
				if (mid == NULL)
					return NULL;
				if (mid->data == n)
					return mid;
				else if (mid->data < n)
					beg = mid->next;
				else
					end = mid;
			} while (end == NULL || end != beg);

			return NULL;
		}
};

const int SIZE = 25;

class HashNode
{
public:
	int key;
	int value;
	HashNode* next;
	HashNode(int key, int value)
	{
		this->key = key;
		this->value = value;
		this->next = NULL;
	}
};


class HashTable
{
private:
	HashNode** htable;
public:
	HashTable()
	{
		htable = new HashNode*[SIZE];
		for (int i = 0; i < SIZE; i++)
			htable[i] = NULL;
	}
	~HashTable()
	{
		for (int i = 0; i < SIZE; ++i){
			HashNode* node = htable[i];
			while (node != NULL){
				HashNode* prev = node;
				node = node->next;
				delete prev;
			}
		}
		delete[] htable;
	}
	 
	int HashFunc(int key) //hashing function
	{
		return key % 10;
	}

	void Insert(int key, int value) //insert into hashtable
	{
		int hashVal = HashFunc(key);
		HashNode* prev = NULL;
		HashNode* node = htable[hashVal];
		while (node != NULL){
			prev = node;
			node = node->next;
		}
		if (node == NULL){
			node = new HashNode(key, value);
			if (prev == NULL)
				htable[hashVal] = node;
			else
				prev->next = node;
		}
		else{
			node->value = value;
		}
	}

	int Search(int key) //search in hashtable
	{
		bool flag = false;
		int hash_val = HashFunc(key);
		HashNode* entry = htable[hash_val];
		while (entry != NULL)
		{
			if (entry->key == key)
			{
				cout << entry->value << " ";
				flag = true;
			}
			entry = entry->next;
		}
		if (!flag)
			return 1;
	}
};

/*
int main(){
	llist list;
	const int SIZE = 10;
	array<int, SIZE> a;
	srand(time(NULL));

	cout << "10 Random Numbers 1-100 ";
	for (int i = 0; i < SIZE; i++) {
		a[i] = rand() % 100 + 1;
		cout << a[i] << " ";
	}
	
	cout << endl;
	sort(begin(a), end(a));
	cout << "Sorted: ";

	for (int i = 0; i < a.size(); i++) {
		cout << a[i] << " ";
	}
	cout << endl;
	cout << "Choose what you would like to do:" << endl << endl;
	int choice;
	int counter = 0;
	do {
		if (counter == 0) {
			cout << "Option 1: Add to list\n";
			cout << "Option 2: Find Value in list linearly\n";
			cout << "Option 3: Find value in list binarily\n";
			cout << "Option 4: End program\n";
		}
		else {
			cout << "Option 2: Find Value in list linearly\n";
			cout << "Option 3: Find value in list binarily\n";
			cout << "Option 4: End program\n";
		}
		cin >> choice;
		cin.ignore();

		if (choice == 1) {
			for (int x : a) {
				list.Insert(x);
			}
			list.PrintList();
			counter += 1;
		}
		else if (choice == 2) {
			int n;
			cout << "What value would you like to find?" << endl;
			cin >> n;
			if (list.FindLinear(n) == NULL)
				cout << "Value not in List\n" << endl;
			else
				cout << "value " << n << " is in the list\n" << endl;
		}
		else if (choice == 3) {
			int n;
			cout << "What value would you like to find?" << endl;
			cin >> n;
			if (list.FindBinary(n) == NULL)
				cout << "Value not in List\n" << endl;
			else
				cout << "value " << n << " is in the list\n" << endl;
		}		
	} while (choice != 4);
	system("pause");
	return 0;
}
*/
int main() {
	HashTable table;
	int key, choice = 0;
	string value;
	while (choice != 3) {
		cout << "Choose which you wish to do\n";
		cout << "Option 1: Insert into table\n";
		cout << "Option 2: Seach for element\n";
		cout << "Option 3: Exit\n";
		cin >> choice;
		switch (choice) {
		case 1:
			cout << "Inserting 25 numbers into table\n";
			array<int, SIZE> arr;
			srand(time(NULL));

			cout << "25 Random Numbers 1-100 ";
			for (int i = 0; i < SIZE; i++) {
				arr[i] = rand() % 100 + 1;
				cout << arr[i] << " ";
			}
			for (int x : arr) {
				cout << "Enter key to where you want to insert the element " << x << endl;
				cin >> key;
				table.Insert(key, x);
			}
			break;

		case 2:
			cout << "Enter key of the element that you want\n";
			cin >> key;
			cout << "Element(s) at key " << key << " -> ";
			if (table.Search(key) == 1) {
				cout << "Element not found at " << key << endl;
				continue;
			}
			break;
		}
	}
	system("pause");
	return 0;
}